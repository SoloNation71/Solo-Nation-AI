import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Brain, ChevronRight, Code, Globe, Layers, Zap } from "lucide-react"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col bg-black text-white">
      <header className="container z-40 flex h-20 items-center justify-between py-6">
        <div className="flex items-center gap-2">
          <Brain className="h-8 w-8 text-purple-500" />
          <span className="text-xl font-bold">Solo Nation</span>
        </div>
        <nav className="hidden gap-6 md:flex">
          <Link href="#vision" className="text-sm font-medium text-gray-300 hover:text-white">
            Vision
          </Link>
          <Link href="#features" className="text-sm font-medium text-gray-300 hover:text-white">
            Features
          </Link>
          <Link href="#roadmap" className="text-sm font-medium text-gray-300 hover:text-white">
            Roadmap
          </Link>
          <Link href="#join" className="text-sm font-medium text-gray-300 hover:text-white">
            Join Us
          </Link>
        </nav>
        <Button className="hidden bg-purple-600 hover:bg-purple-700 md:inline-flex">Get Started</Button>
        <Button variant="outline" size="icon" className="md:hidden">
          <ChevronRight className="h-4 w-4" />
          <span className="sr-only">Menu</span>
        </Button>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48 border-b border-gray-800">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-blue-500">
                    The Future of AI-Driven Economy
                  </h1>
                  <p className="max-w-[600px] text-gray-300 md:text-xl">
                    Solo Nation is building a new economic paradigm where AI and human creativity converge to create
                    unprecedented value and opportunity.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Button className="bg-purple-600 hover:bg-purple-700">Join the Movement</Button>
                  <Button
                    variant="outline"
                    className="border-gray-700 text-gray-300 hover:bg-gray-800 hover:text-white"
                  >
                    Learn More
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative h-[300px] w-[300px] md:h-[400px] md:w-[400px] lg:h-[500px] lg:w-[500px]">
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 opacity-20 blur-3xl"></div>
                  <Image
                    src="/placeholder.svg?height=500&width=500"
                    alt="AI Network Visualization"
                    width={500}
                    height={500}
                    className="relative z-10"
                    priority
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="vision" className="w-full py-12 md:py-24 lg:py-32 bg-gray-950 border-b border-gray-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-purple-500/10 px-3 py-1 text-sm text-purple-500">
                  Our Vision
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Redefining Economic Value</h2>
                <p className="max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Solo Nation envisions a world where AI systems work alongside humans to create a more equitable,
                  efficient, and innovative economy. We're building the infrastructure for a new kind of economic system
                  that values creativity, collaboration, and contribution over traditional metrics.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-2 lg:gap-12">
              <Image
                src="/placeholder.svg?height=400&width=500"
                alt="AI Economy Visualization"
                width={500}
                height={400}
                className="mx-auto aspect-video overflow-hidden rounded-xl object-cover object-center sm:w-full lg:order-last"
              />
              <div className="flex flex-col justify-center space-y-4">
                <ul className="grid gap-6">
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-purple-400">AI-Human Collaboration</h3>
                      <p className="text-gray-400">
                        We're creating systems where AI and humans work together, each contributing their unique
                        strengths to solve complex problems.
                      </p>
                    </div>
                  </li>
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-purple-400">Decentralized Value Creation</h3>
                      <p className="text-gray-400">
                        Our platform enables individuals to create and capture value in ways previously impossible in
                        traditional economic systems.
                      </p>
                    </div>
                  </li>
                  <li>
                    <div className="grid gap-1">
                      <h3 className="text-xl font-bold text-purple-400">Sustainable Growth</h3>
                      <p className="text-gray-400">
                        We're building economic models that prioritize long-term sustainability over short-term gains.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="w-full py-12 md:py-24 lg:py-32 border-b border-gray-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-purple-500/10 px-3 py-1 text-sm text-purple-500">
                  Features
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Building Blocks of the New Economy</h2>
                <p className="max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Solo Nation provides the tools and infrastructure needed to participate in the AI-driven economy of
                  tomorrow.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl gap-8 py-12 md:grid-cols-2 lg:grid-cols-3">
              <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 p-6 bg-gray-900/50">
                <div className="rounded-full bg-purple-500/10 p-3">
                  <Brain className="h-6 w-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold">AI Integration</h3>
                <p className="text-center text-gray-400">
                  Seamlessly integrate AI capabilities into your projects and workflows.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 p-6 bg-gray-900/50">
                <div className="rounded-full bg-purple-500/10 p-3">
                  <Globe className="h-6 w-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold">Global Network</h3>
                <p className="text-center text-gray-400">
                  Connect with collaborators and resources from around the world.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 p-6 bg-gray-900/50">
                <div className="rounded-full bg-purple-500/10 p-3">
                  <Code className="h-6 w-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold">Open Protocols</h3>
                <p className="text-center text-gray-400">
                  Build on transparent, open-source protocols that ensure fairness and accessibility.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 p-6 bg-gray-900/50">
                <div className="rounded-full bg-purple-500/10 p-3">
                  <Layers className="h-6 w-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold">Value Layers</h3>
                <p className="text-center text-gray-400">
                  Create and capture value across multiple layers of the economic stack.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 p-6 bg-gray-900/50">
                <div className="rounded-full bg-purple-500/10 p-3">
                  <Zap className="h-6 w-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold">Rapid Deployment</h3>
                <p className="text-center text-gray-400">
                  Launch your ideas quickly with our streamlined development tools.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-2 rounded-lg border border-gray-800 p-6 bg-gray-900/50">
                <div className="rounded-full bg-purple-500/10 p-3">
                  <Brain className="h-6 w-6 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold">Intelligent Markets</h3>
                <p className="text-center text-gray-400">
                  Participate in markets that adapt and evolve based on real-time data and AI insights.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="roadmap" className="w-full py-12 md:py-24 lg:py-32 bg-gray-950 border-b border-gray-800">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-purple-500/10 px-3 py-1 text-sm text-purple-500">
                  Roadmap
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Our Journey Forward</h2>
                <p className="max-w-[900px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  The path to a new economic paradigm is ambitious but achievable. Here's how we're getting there.
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-3xl space-y-8 py-12">
              <div className="relative pl-8 pb-8 border-l border-gray-800">
                <div className="absolute left-0 top-0 flex h-6 w-6 items-center justify-center rounded-full bg-purple-500 -translate-x-1/2">
                  <span className="text-xs font-bold">1</span>
                </div>
                <h3 className="text-xl font-bold text-purple-400">Foundation (2023)</h3>
                <p className="mt-2 text-gray-400">
                  Building the core infrastructure and protocols that will power the Solo Nation ecosystem.
                </p>
              </div>
              <div className="relative pl-8 pb-8 border-l border-gray-800">
                <div className="absolute left-0 top-0 flex h-6 w-6 items-center justify-center rounded-full bg-purple-500 -translate-x-1/2">
                  <span className="text-xs font-bold">2</span>
                </div>
                <h3 className="text-xl font-bold text-purple-400">Expansion (2024)</h3>
                <p className="mt-2 text-gray-400">
                  Growing our community and launching the first wave of AI-powered economic applications.
                </p>
              </div>
              <div className="relative pl-8 pb-8 border-l border-gray-800">
                <div className="absolute left-0 top-0 flex h-6 w-6 items-center justify-center rounded-full bg-purple-500 -translate-x-1/2">
                  <span className="text-xs font-bold">3</span>
                </div>
                <h3 className="text-xl font-bold text-purple-400">Integration (2025)</h3>
                <p className="mt-2 text-gray-400">
                  Connecting with existing economic systems and creating bridges to traditional markets.
                </p>
              </div>
              <div className="relative pl-8">
                <div className="absolute left-0 top-0 flex h-6 w-6 items-center justify-center rounded-full bg-purple-500 -translate-x-1/2">
                  <span className="text-xs font-bold">4</span>
                </div>
                <h3 className="text-xl font-bold text-purple-400">Transformation (2026+)</h3>
                <p className="mt-2 text-gray-400">
                  Scaling the new economic paradigm globally and revolutionizing how value is created and distributed.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="join" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container grid items-center gap-6 px-4 md:px-6 lg:grid-cols-2 lg:gap-10">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Join the Solo Nation Movement</h2>
              <p className="max-w-[600px] text-gray-400 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Be part of building the future of the AI-driven economy. Sign up today to get early access to our
                platform and updates on our progress.
              </p>
            </div>
            <div className="flex flex-col gap-4 rounded-xl border border-gray-800 bg-gray-950 p-6">
              <h3 className="text-xl font-bold">Get Early Access</h3>
              <div className="space-y-4">
                <div className="grid gap-2">
                  <Input
                    type="text"
                    placeholder="Name"
                    className="bg-gray-900 border-gray-800 text-white placeholder:text-gray-500"
                  />
                </div>
                <div className="grid gap-2">
                  <Input
                    type="email"
                    placeholder="Email"
                    className="bg-gray-900 border-gray-800 text-white placeholder:text-gray-500"
                  />
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Join the Waitlist</Button>
                <p className="text-xs text-gray-500">
                  By signing up, you agree to our{" "}
                  <Link href="#" className="text-purple-400 hover:underline">
                    Terms of Service
                  </Link>{" "}
                  and{" "}
                  <Link href="#" className="text-purple-400 hover:underline">
                    Privacy Policy
                  </Link>
                  .
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t border-gray-800 py-6">
        <div className="container flex flex-col items-center justify-between gap-4 px-4 md:flex-row md:px-6">
          <div className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-purple-500" />
            <span className="text-lg font-bold">Solo Nation</span>
          </div>
          <p className="text-center text-sm text-gray-500 md:text-left">
            &copy; {new Date().getFullYear()} Solo Nation. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="#" className="text-gray-400 hover:text-white">
              Twitter
            </Link>
            <Link href="#" className="text-gray-400 hover:text-white">
              Discord
            </Link>
            <Link href="#" className="text-gray-400 hover:text-white">
              GitHub
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
